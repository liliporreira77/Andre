<?php //verifica_session();
// verifica_nivel();
include_once 'core/conexao.php';
?>
<div class="container content__boxed" style="text-align: center;">
    <div id="divCenter">
        <div class="form-block">
            <h1>Novo Tipo de Utilizador <br> </h1>
            <h1> </h1>
            <form method="post" action="" id="novoregisto">
                <div id="msg_num_mec"></div>
                <?php
                $sql = mysqli_query($con, "SELECT Max(nivel.id_nivel) AS MaxDeid_nivel FROM nivel");
                $row = mysqli_fetch_row($sql);
                $id = $row[0] + 1;
                ?>
                <div id="formfields">
                    <div class="form-itens form-pequenos">
                        <input type="text" id="id_nivel" name="id_nivel" value="<?php echo $id ?>"
                            placeholder="id_nivel">
                    </div>

                    <div class="form-itens">

                        <input type="text" name="nome" id="nome" placeholder="Insira o nome do tipo de utilizador"
                            autofocus><br>
                    </div>


                    <div class="form-itens">
                        <input type="text" name="descricao" id="descricao" placeholder="Insira a descrição"><br>
                    </div>
                    <br><br>
                    <div class="labelbotton">
                        <input class="button-default button-default-small" id="submit_new_user" type="button"
                            value="Inserir Tipo">
                    </div>
                </div>
            </form>
            <div align=" center" class="form-ok">
                <script type="text/javascript">
                $(document).ready(function() {


                    //validação
                    $('#submit_new_user').click(function() {
                        var oid_nivel = $('#id_nivel').val();
                        var aDescricao = $('#descricao').val();
                        var oNome = $('#nome').val();
                        $.ajax({
                            url: "template/nivel_inserir_actions.php",
                            type: "POST",
                            data: {
                                id_nivel: oid_nivel,
                                nome: oNome,
                                descricao: aDescricao
                            }
                        }).done(function(data) {
                            //console.log(data);
                            //alert(data);

                            //TUDO OK
                            if (data == 0) //Existe
                            {
                                $('#msg_num_mec').html(
                                    '<div id="alert-senha" class="alert alert-success alert-dismissible show" role="alert">O tipo de utilizador foi inserido com sucesso!</div>'
                                );
                                //$('#Terminar Registo').prop('disabled', true);
                            }

                            //ID do tipo
                            if (data == 1) //Existe
                            {
                                $('#msg_num_mec').html(
                                    '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">O ID tipo de utilizador já existe! Insira o número seguinte</div>'
                                );
                                $('#Terminar Registo').prop('disabled', true);
                            }
                            if (data == 3) //Existe
                            {
                                $('#msg_num_mec').html(
                                    '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">Todos os campos são de preenchimento obrigatório. Por favor, preencha os campos vazios.</div>'
                                );
                                $('#Terminar Registo').prop('disabled', true);
                            }

                            //Validar nome tipo de utilizador
                            if (data == 2) //Existe
                            {
                                $('#msg_num_mec').html(
                                    '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">Já existe outro tipo de utilizador com o mesmo nome!</div>'
                                );

                                //$('#Terminar Registo').prop('disabled', true);
                            }

                        }).fail(function(jqXHR, textStatus) {
                            console.log("Request failed: " + textStatus);
                        });
                    });
                });
                </script>