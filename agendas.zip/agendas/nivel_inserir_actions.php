<?php
include_once('../core/conexao.php');
include_once('../core/config.php');
verifica_nivel();
// VERIFICA SE É VAZIO
if ((empty($_POST['id_nivel'])) or (empty($_POST['nome'])) or (empty($_POST['descricao'])))
	echo 3;
else {
	//VERIFICA IDnivel
	if (isset($_POST['id_nivel'])) {
		$id_nivel = (int) filter_var($_POST['id_nivel'], FILTER_SANITIZE_STRING);
		$nome_nivel = filter_var($_POST['nome'], FILTER_SANITIZE_STRING);
		$descricao = filter_var($_POST['descricao'], FILTER_SANITIZE_STRING);
		if ($stmt = $con->prepare("SELECT id_nivel, nome_nivel FROM nivel WHERE id_nivel=? or nome_nivel=?")) {
			$stmt->bind_param('ss', $id_nivel, $nome_nivel);
			$stmt->execute();
			$result = $stmt->get_result();

			$numrow = $result->num_rows;

			if ($numrow <= 0) {
				echo 0;
				// INSERIR NA BASE DE DADOS
				$stmt = $con->prepare("INSERT INTO nivel (id_nivel, nome_nivel, descricao) VALUES (?, ?, ?)");
				$stmt->bind_param('iss', $id_nivel, $nome_nivel, $descricao);
				$stmt->execute();
				$stmt->close();
			} else if ($numrow >= 1) {
				$row = mysqli_fetch_array($result);
				$id_nivel_i = $row['id_nivel'];
				$nome_nivel_i = $row['nome_nivel'];
				if ($id_nivel == $id_nivel_i && $nome_nivel != $nome_nivel_i)
					echo 1;
				else echo 2;
			}
		} else echo 'erro de conexão!';
	}
}