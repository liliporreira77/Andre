<?php
include_once('../core/conexao.php');
include_once('../core/config.php');

if ((empty($_POST['nome_nivel'])) or (empty($_POST['descricao'])))
    echo 1;
else {
    //VERIFICA IDnivel
    if (isset($_POST['id_nivel'])) {
        $id_nivel = (int) filter_var($_POST['id_nivel'], FILTER_SANITIZE_STRING);
        $nome_nivel = filter_var($_POST['nome_nivel'], FILTER_SANITIZE_STRING);
        $descricao = filter_var($_POST['descricao'], FILTER_SANITIZE_STRING);
    }
}
$stmt = $con->prepare("SELECT id_nivel, nome_nivel, descricao FROM nivel WHERE id_nivel<>? and (nome_nivel=? or descricao=?)");
$stmt->bind_param('sss', $id_nivel, $nome_nivel, $descricao);
$stmt->execute();
$result = $stmt->get_result();
$numrow = $result->num_rows;

if ($numrow >= 1) {
    $row = mysqli_fetch_array($result);
    $id_nivel_i = $row['id_nivel'];
    $nome_nivel_i = $row['nome_nivel'];
    $descricao_i = $row['descricao'];
    if ($nome_nivel == $nome_nivel_i) {
        echo 3;
        die();
    }
}
// UPDATE NA BASE DE DADOS
$sql = "UPDATE nivel SET nome_nivel='$nome_nivel', descricao='$descricao' WHERE id_nivel=$id_nivel";
if (mysqli_query($con, $sql)) {
    echo 0;
    die();
}