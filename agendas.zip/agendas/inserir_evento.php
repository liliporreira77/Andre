<?php

// Incluir o arquivo com a conexão com banco de dados
include_once './conexao.php';

// Receber os dados enviado pelo JavaScript
$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);


// Recuperar os dados do usuário no banco de dados
$query_user = "SELECT user_id, nome_login, email FROM login where user_id=:user_id LIMIT 1";

// Prepara a QUERY
$result_user = $conn->prepare($query_user);

// Substituir o link pelo valor
$result_user->bindParam(':user_id', $dados['ins_utilizador']);

// Executar a QUERY
$result_user->execute();

// Criar a QUERY cadastrar evento no banco de dados
$query_ins_event = "INSERT INTO events (title,obs, id_color, start, end,user_id) VALUES (:title, :obs, :id_color, :start, :end, :user_id)";

// Prepara a QUERY
$ins_event = $conn->prepare($query_ins_event);

// // Substituir o link pelo valor
$ins_event->bindParam(':title', $dados['ins_title']);
$ins_event->bindParam(':obs', $dados['ins_obs']);
$ins_event->bindParam(':id_color', $dados['ins_color']);
$ins_event->bindParam(':start', $dados['ins_start']);
$ins_event->bindParam(':end', $dados['ins_end']);
$ins_event->bindParam(':user_id', $dados['ins_utilizador']);

// // Verificar se consegui cadastrar corretamente
if ($ins_event->execute()) {
    $retorna = ['status' => true, 
    'msg' => 'Evento foi inserido com sucesso!', 
    'id' => $conn->lastInsertId(), 
    'title' => $dados['ins_title'], 
    'obs' => $dados['ins_obs'], 
    'id_color' => $dados['ins_color'], 
    'start' => $dados['ins_start'], 
    'end' => $dados['ins_end'], 
    'user_id' => $dados['ins_utilizador']];
} else {
    $retorna = ['status' => false, 'msg' => 'Erro: Evento não foi inserido!'];
}

// Converter o array em objeto e retornar para o JavaScript
echo json_encode($retorna);
