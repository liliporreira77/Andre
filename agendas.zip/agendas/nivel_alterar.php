<?php verifica_session();
verifica_nivel();

?>
<div class="container content__boxed" style="text-align: center;">
    <div id="divCenter">
        <div class="form-block">
            <form method="post" action="" id="novoregisto">
                <?php
                $userid = isset($_GET['userid']) ? $_GET['userid'] : '';
                if ($userid != '') {
                    $nmec = $userid; ?>
                    <h1>Editar Tipo de Utilizador<br> </h1>
                    <h1> </h1>
                <?php }
                $result = mysqli_query($con, "SELECT * FROM nivel WHERE id_nivel = $nmec LIMIT 1");
                $row = mysqli_fetch_row($result);
                $id_nivel = $row[0]; //echo $id_nivel
                $nome_nivel = $row[1];
                $descricao = $row[2];

                ?>

                <div id="msg_num_mec"></div>

                <div id="formfields">
                    <input type="hidden" id="id_nivel" name="id_nivel" value="<?php echo $id_nivel ?>">

                    <div class="form-itens">Designação: </div>
                    <div class="form-itens"><input type="text" name="nome_nivel" id="nome_nivel" value="<?php echo $nome_nivel ?>"><br></div>

                    <div class="form-itens">Descrição: </div>
                    <div lass="form-itens"><input type="text" name="descricao" id="descricao" value="<?php echo $descricao ?>"><br></div>

                    <div class="labelbotton"> <input id="submit_new_user" type="button" value="Gravar" class="button-default button-default-small">
                    </div>
                </div>
            </form>
            <div class="form-ok">


                <script type="text/javascript">
                    $(document).ready(function() {
                        function myfunction() {
                            $.getJSON('template/divisao_inserir_number.php', {
                                user_id: $("#user_id").val()
                            }, function(data) {
                                $("#nome_login").val(data.nome_login);
                                $("#email").val(data.email);
                            });
                        }
                        var userid = '<?php echo  $userid; ?>';
                        if (userid != '') {
                            myfunction();

                        }


                        //validação
                        $('#submit_new_user').click(function() {
                            var oid_nivel = $('#id_nivel').val();
                            var onome_nivel = $('#nome_nivel').val();
                            var adescricao = $('#descricao').val();
                            $.ajax({
                                url: "template/nivel_alterar_actions.php",
                                type: "POST",
                                data: {
                                    id_nivel: oid_nivel,
                                    nome_nivel: onome_nivel,
                                    descricao: adescricao,
                                }
                            }).done(function(data) {
                                //	console.log(data);
                                //alert(data);
                                //TUDO OK
                                if (data == 0) //Existe
                                {
                                    $('#msg_num_mec').html(
                                        '<div id="alert-senha" class="alert alert-success alert-dismissible show" role="alert">O Tipo de Utilizador foi atualizado com sucesso!</div>'
                                    );
                                    setTimeout(function() {
                                        history.back();
                                    }, 3000);
                                    //$('#Terminar Registo').prop('disabled', true);
                                }

                                //Validar Preenchimento obrigatório
                                if (data == 1) //Existe
                                {
                                    $('#msg_num_mec').html(
                                        '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">Todos os campos são de preenchimento obrigatório. Por favor, complete o formulário!</div>'
                                    );

                                    //$('#Terminar Registo').prop('disabled', true);
                                }

                                //Validar nome_nivel
                                else if (data == 3) //Existe
                                {
                                    $('#msg_num_mec').html(
                                        '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">Já existe outro Tipo de Utilizador com o mesmo nome! Tente outro nome ou mantanha o mesmo.</div>'
                                    );

                                    //$('#Terminar Registo').prop('disabled', true);
                                }

                            }).fail(function(jqXHR, textStatus) {
                                console.log("Request failed: " + textStatus);
                            });
                        });



                        $("#user_id").blur(myfunction);


                    });
                </script>
            </div>
        </div>
    </div>
</div>