<span id="msg"></span>
<div id='calendar'></div>
<!-- Button trigger modal -->

<?php  include_once './conexao.php';
$sql = "SELECT * FROM color ORDER BY nome_tipo";

$result = $conn->query($sql);

/* fetch associative array */

?>
<!-- Modal visualizar-->
<div class="modal fade" id="visualizarModal" tabindex="-1" aria-labelledby="visualizarModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="visualizarModalLabel">Detalhes do Evento</h1>

                <h1 class="modal-title fs-5" id="editarModalLabel" style="display: none;">Editar o Evento</h1>

                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

                <span id="msgViewEvento"></span>

                <div id="visualizarEvento">
                    <dl class="row">
                        <dt class="col-sm-4">Número do evento</dt>
                        <dd class="col-sm-9" id="visualizar_id"></dd>
                    </dl>

                    <dl class="row">
                        <dt class="col-sm-4">Título</dt>
                        <dd class="col-sm-9" id="visualizar_titulo"></dd>
                    </dl>

                    <dl class="row">
                        <dt class="col-sm-3">Observação: </dt>
                        <dd class="col-sm-11" id="visualizar_obs"></dd>
                    </dl>

                    <dl class="row">
                        <dt class="col-sm-4">Ínício</dt>
                        <dd class="col-sm-9" id="visualizar_inicio"></dd>
                    </dl>

                    <dl class="row">
                        <dt class="col-sm-4">Fim</dt>
                        <dd class="col-sm-9" id="visualizar_fim"></dd>
                    </dl>

                    <dl class="row">
                        <dt class="col-sm-3">id_color: </dt>
                        <dd class="col-sm-9" id="visualizar_id_color"></dd>
                    </dl>                    
                    
                    <dl class="row">
                        <dt class="col-sm-3">nome_tipo: </dt>
                        <dd class="col-sm-9" id="visualizar_nome_tipo"></dd>
                    </dl>



                    <dl class="row">
                        <dt class="col-sm-3">user_id: </dt>
                        <dd class="col-sm-9" id="visualizar_user_id"></dd>

                    </dl>
                    <dl class="row">
                        <dt class="col-sm-3">visualizar_nome_login: </dt>
                        <dd class="col-sm-9" id="visualizar_nome_login"></dd>

                    </dl>


                    <button class="btn btn-warning" id="btnEdiEvento">Editar</button>

                    <button type="button" class="btn btn-danger" id="btnApagarEvento">Apagar</button>
                </div>

                <div id="editarEvento" style="display: none;">

                    <span id="msgEditEvento"></span>

                    <form method="POST" id="formEditEvento">

                        <input type="hidden" name="edit_id" id="edit_id">

                        <div class="row mb-3">
                            <label for="edit_title" class="col-sm-2 col-form-label">Título</label>
                            <div class="col-sm-10">
                                <input type="text" name="edit_title" class="form-control" id="edit_title"
                                    placeholder="Título do evento">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="edit_obs" class="col-sm-2 col-form-label">Observação</label>
                            <div class="col-sm-10">
                                <input type="text" name="edit_obs" class="form-control" id="edit_obs"
                                    placeholder="Observação do evento">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="edit_start" class="col-sm-2 col-form-label">Início</label>
                            <div class="col-sm-10">
                                <input type="datetime-local" name="edit_start" class="form-control" id="edit_start">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="edit_end" class="col-sm-2 col-form-label">Fim</label>
                            <div class="col-sm-10">
                                <input type="datetime-local" name="edit_end" class="form-control" id="edit_end">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="edit_color" class="col-sm-3 col-form-label">Tipo evento</label>
                            <div class="col-sm-9">
                                <select name="edit_color" id="edit_color">
                                    <option value="">Escolha</option>

                                </select>
                            </div>
                        </div>

                        <div class="row mb-3">

                            <label for="edit_utilizador" class="col-sm-3 col-form-label">Utilizador</label>
                            <div class="col-sm-9">
                                <select name="edit_utilizador" id="edit_utilizador">
                                    <option value="">Escolha</option>

                                </select>
                            </div>
                        </div>


                        <button type="button" name="btnViewEvento" class="btn btn-primary"
                            id="btnViewEvento">Cancelar</button>

                        <button type="submit" name="btnEditEvento" class="btn btn-warning"
                            id="btnEditEvento">Guardar</button>

                    </form>

                </div>
            </div>

        </div>
    </div>
</div>

</div>

<!-- Modal inserir-->
<div class="modal fade" id="inserirModal" tabindex="-1" aria-labelledby="inserirModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-6" id="inserirModalLabel">Inserir novo evento</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <span id="msgInsEvent"></span>
                <form method="post" id="insertEvent">
                    <div class="row mb-3">
                        <label for="ins_title" class="col-sm-3 col-form-label">Título</label>
                        <div class="col-sm-9">
                            <input type="name" name="ins_title" class="form-control" id="ins_title"
                                placeholder="Título do evento">
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="ins_obs" class="col-sm-3 col-form-label">Observações</label>
                        <div class="col-sm-9">
                            <input type="name" name="ins_obs" class="form-control" id="ins_obs"
                                placeholder="Observações do evento">
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="ins_start" class="col-sm-3 col-form-label">Data inícial</label>
                        <div class="col-sm-9">
                            <input type="datetime-local" name="ins_start" class="form-control" id="ins_start">
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="ins_end" class="col-sm-3 col-form-label">Data final</label>
                        <div class="col-sm-9">
                            <input type="datetime-local" name="ins_end" class="form-control" id="ins_end">
                        </div>
                    </div>

                    <div class="row mb-3">

                        <label for="ins_color" class="col-sm-3 col-form-label">Tipo evento</label>
                        <div class="col-sm-9">
                            <select name="ins_color" id="ins_color">
                                <option value="">Escolha</option>

                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">

                        <label for="ins_utilizador" class="col-sm-3 col-form-label">Utilizador</label>
                        <div class="col-sm-9">
                            <select name="ins_utilizador" id="ins_utilizador">
                                <option value="">Escolha</option>

                            </select>
                        </div>
                    </div>
                    <button type="submit" name="btnInsEvento" class="btn btn-success" id="btnInsEvento">Inserir</button>

                </form>
            </div>
        </div>
    </div>