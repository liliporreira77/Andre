Andre Rodrigues
<?php
include_once 'conexao.php';

try {
    // Conexão com o banco de dados usando PDO


    // Consulta SQL para obter a data e hora do evento específico
    $sql = "SELECT data_hora FROM events ";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':id_evento', $id);
    $stmt->execute();

    // Variável para armazenar a data e hora do evento
    $data_hora_evento = "";

    // Verifica se há resultados na consulta
    if ($stmt->rowCount() > 0) {
        // Obtém a linha de resultado
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        // Armazena a data e hora do evento
        $data_hora_evento = $row['data_hora'];
    }
} catch(PDOException $e) {
    echo "Erro de conexão: " . $e->getMessage();
}

// Fecha a conexão com o banco de dados (opcional, pois o PDO fecha automaticamente quando o script termina)
$pdo = null;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Exemplo de Input DateTime com PDO e MySQL</title>
</head>
<body>

<form>
    <label for="data_hora">Selecione a data e hora do evento:</label>
    <input type="datetime-local" id="data_hora" name="data_hora" value="<?php echo $data_hora_evento; ?>">
</form>

</body>
</html>