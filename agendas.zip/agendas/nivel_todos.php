<?php verifica_session();
verifica_nivel();
include('core/conexao.php');
?>
<!-- MDBootstrap Datatables  -->
<div class='container-fluid'>
  <div class='row'>
    <div class='col-12' style='padding-top:25px;'>
      <?php if ($_SESSION['id_nivel'] == 1) { ?>
        <div style="width:100%;  max-width: 100% !important; padding:0%!important;">
        <?php } else { ?>
          <div style="width:100%;  max-width: 100% !important; padding:0%!important;">
          <?php } ?>
          <table id='example' class='table table-striped table-bordered'>
            <thead>
              <!--O numero de colunas-->
              <tr>
                <th class='tableth'>ID</th>
                <th class='tableth'>Nome do nivel</th>
                <th class='tableth'>Descrição</th>
                <th class='tableth'>ações</th>
              </tr>
            </thead>
            <tbody> <?php
                    echo '<tr>';
                    $result = 'SELECT * From nivel';
                    $resultado = mysqli_query($con, $result);
                    while ($row = mysqli_fetch_assoc($resultado)) {
                      echo '<td align=center>' . $row['id_nivel'] . '</td> ';
                      echo '<td align=center>' . $row['nome_nivel'] . '</td> ';
                      echo '<td align=center>' . $row['descricao'] . '</td> ';
                    ?> <td style='padding: 4px; width:80px; text-align: center;'>
                  <button type='button' onclick="acaoDoAdministrador('<?php echo $row['id_nivel']; ?>','delete');" class='btn btn-danger btn-sm btn-admin-actions' title='Apagar'><span class='fas fa-times fa-sm'></span> </button>
                  <button type='button' onclick="acaoDoAdministrador('<?php echo $row['id_nivel']; ?>','edit');" class='btn btn-success btn-sm btn-admin-actions' title='Editar'><span class='fas fa-edit  fa-sm'></span> </button>
                </td> <?php
                      echo '</tr>';
                    }
                      ?>
          </table>
          <br> <br>
          </div>
        </div>
    </div>
  </div>
</div>
<script type='text/javascript'>
  $(document).ready(function() {
    var table = $('#example').DataTable({
      order: [
        [1, 'asc']
      ],
      lengthChange: false,
      <?php if ($_SESSION[' id_nivel'] == 1) {
      ?>
        buttons: ['copy', 'excel', 'pdf'],
      <?php } ?> 'language': {
        'sProcessing': 'Procesando...',
        'sLengthMenu': 'Mostrar _MENU_ registros',
        'sZeroRecords': 'Não foram encontrados nenhum resultado',
        'sEmptyTable': ' Não há dados disponíveis nesta tabela',
        'sInfo': '_START_ até _END_ de um total de _TOTAL_ registros',
        'sInfoEmpty': '0 até 0 de um total de 0 registros',
        'sInfoFiltered': '(filtrado de um total de _MAX_ registros)',
        'sInfoPostFix': '',
        'sSearch': '',
        'searchPlaceholder': 'Procurar',
        'sUrl': '',
        'sInfoThousands': ',',
        'sLoadingRecords': 'Carregando...',
        'oPaginate': {
          'sFirst': 'Primeiro',
          'sLast': 'Último',
          'sNext': 'Próximo',
          'sPrevious': 'Anterior'
        },
        'oAria': {
          'sSortAscending': ': Activar para ordenar a columa de maneira ascendente',
          'sSortDescending': ': Activar para ordenar a coluna de maneira descendente'
        }
      }
    });
    table.buttons().container().appendTo('#example_wrapper .col-md-6:eq(0)');
  });

  function acaoDoAdministrador(id, acao) {
    if (acao == 'delete') {
      let text = 'Pertende apagar este Nível dos contactos?';
      if (confirm(text) == true) {
        var action_type = 1;
        // se for do tipo 'deletar usuário do sistema'
        txt = 'You pressed OK!';
        setTimeout(function() {
          window.location.reload();
        }, 2500);
      } else {
        text = 'Cancelar!';
      }
    } else if (acao == 'edit') {
      var action_type = 2;
      // se for do tipo 'editar dados do usuário'
    }
    //Faz a requisição para o script em 'registo_todos_actions.php'
    $.ajax({
      url: 'template/nivel_todos_actions.php',
      type: 'POST',
      data: {
        usertarget: id,
        acttp: action_type
      },
      dataType: 'json',
      success: function(data) {
        //alert( data );
        //console.log ( data );
        if (data.retorno == 1) {
          window.location.href = '?pg=8&userid=' + data.userid;
        } else if (data.retorno == 0) {
          setTimeout(function() {
            window.location.reload();
          }, 2500);
        }
      }
    });
  }
</script>
</div>