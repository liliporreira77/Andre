<?php

// Incluir o arquivo com a conexão com banco de dados
include_once './conexao.php';
// Receber os dados enviado pelo JavaScript
$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

// Recuperar os dados do usuário no banco de dados
$query_user = "SELECT user_id,nome_login, email FROM login WHERE user_id =:user_id LIMIT 1";

// Prepara a QUERY
$result_user = $conn->prepare($query_user);

// Substituir o link pelo valor
$result_user->bindParam(':user_id', $dados['ins_utilizador']);

// Executar a QUERY
$result_user->execute();

// // Recuperar os dados do cor
// $query_cor = "SELECT nome_tipo FROM color WHERE id_color =:id_color LIMIT 1";

// // Prepara a QUERY
// $result_cor = $conn->prepare($query_cor);

// // Substituir o link pelo valor
// $result_cor->bindParam(':nome_tipo', $dados['nome_tipo']);

// // Executar a QUERY
// $result_cor->execute();

// QUERY para recuperar os eventos
$query_events = "SELECT events.id, events.title, events.obs, events.start, events.end, color.nome_tipo, color.id_color, login.user_id, login.nome_login FROM login INNER JOIN (color INNER JOIN events ON color.id_color = events.id_color) ON (login.user_id = events.user_id) AND (login.user_id = events.user_id)";

// Prepara a QUERY
$result_events = $conn->prepare($query_events);

// Executar a QUERY
$result_events->execute();

// Criar o array que recebe os eventos
$eventos = [];

// Percorrer a lista de registros retornado do banco de dados
while($row_events = $result_events->fetch(PDO::FETCH_ASSOC)){

    // Extrair o array
    extract($row_events);

    $eventos[] = [
        'id' => $id,
        'title' => $title,
        'id_color' => $id_color,
        'nome_tipo' => $nome_tipo,
        'start' => $start,
        'end' => $end,
        'obs' => $obs,
        'user_id' => $user_id,
        'nome_login' => $nome_login,
    ];
}

echo json_encode($eventos);